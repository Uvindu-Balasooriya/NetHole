NetHole for Windows
===================
1. Double-click NetHole.exe and click Yes on the admin prompt (port 53 needs it).
   If Windows SmartScreen appears: More info > Run anyway (the app is not code-signed).
2. In the dashboard, click "Use NetHole as this PC's DNS".
3. Use "Quit NetHole" in the dashboard to stop it and restore your DNS settings.

Other devices: set their DNS server to this PC's IP address.
CPU temperature: keep LibreHardwareMonitor running in the background.
Closing the window leaves NetHole filtering in the background; run NetHole.exe again to reopen it.
