# NetHole

Block ads, trackers and malware for every device on your network.

NetHole is a DNS sinkhole for Windows. It checks each domain lookup against
a block list of about 70,000 domains and stops the bad ones before they load.
A built-in dashboard shows what is happening, along with your PC's CPU
temperature, CPU load and RAM usage.

## Features

- DNS filtering with a block list that updates on demand
- Live dashboard: queries, blocked count, block rate, response time,
  24-hour chart, top blocked domains, query log
- System monitor: CPU temperature, CPU load (total and per core), RAM usage
- Custom block and allow rules
- Pause blocking, update lists, or switch this PC's DNS with one click
- Other devices can use this PC's IP address as their DNS server
- Single file, no installer, no runtime needed

## Install

1. Download `NetHole-Windows.zip` from [Releases](../../releases).
2. Extract it and double-click `NetHole.exe`.
3. Click Yes on the admin prompt (port 53 needs it). If SmartScreen appears,
   choose More info, then Run anyway. The app is not code-signed.
4. In the dashboard, click "Use NetHole as this PC's DNS".

Use "Quit NetHole" in the dashboard to stop it and restore your DNS settings.

## Use it on other devices

Set the DNS server on a phone, TV or laptop to this PC's IP address.
Windows Firewall may ask to allow NetHole the first time.

## CPU temperature

Windows does not expose CPU temperature reliably. NetHole reads it from
[LibreHardwareMonitor](https://github.com/LibreHardwareMonitor/LibreHardwareMonitor)
if it is running, and otherwise from the built-in Windows thermal zone, which
many PCs do not report. If neither works, the dashboard shows "n/a".

## Build from source

Requires Go 1.22 or newer.

```
GOOS=windows GOARCH=amd64 go build -trimpath -ldflags "-s -w -H=windowsgui" -o NetHole.exe .
```

## Configuration

Environment variables: `NETHOLE_DNS_PORT` (default 53), `NETHOLE_WEB_PORT`
(default 8053), `NETHOLE_BIND` (default 0.0.0.0), `NETHOLE_NOGUI`.
Block lists and custom rules are stored in `%APPDATA%\NetHole`.

## Security

- The dashboard listens on 127.0.0.1 only and rejects requests from other
  sites or hostnames.
- Only UDP DNS is handled for now. There is no encrypted DNS (DoH/DoT) yet.

## Known limits

- Stats reset when the app closes.
- Not code-signed, so SmartScreen will warn.
- Tested on Linux during development. Windows-specific parts (admin prompt,
  CPU and RAM readings, temperature lookup, DNS switch) need more testing.

## Website

`website/index.html` is the project's landing page. The download and
login features there only work on the original claude.ai host.

## License

MIT
