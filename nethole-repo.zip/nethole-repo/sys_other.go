//go:build !windows

package main

import (
	"fmt"
	"os"
	"strconv"
	"strings"
)

func isAdmin() bool   { return true }
func elevate() bool   { return false }
func openUI(u string) { fmt.Println("NetHole running:", u) }

func osSetDNS(bool) (bool, string) { return false, "Only available on Windows." }

func readCores() (busy, total []uint64, ok bool) {
	raw, err := os.ReadFile("/proc/stat")
	if err != nil {
		return
	}
	for _, l := range strings.Split(string(raw), "\n") {
		f := strings.Fields(l)
		if len(f) > 8 && strings.HasPrefix(f[0], "cpu") && f[0] != "cpu" {
			var t, idle uint64
			for i, s := range f[1:] {
				v, _ := strconv.ParseUint(s, 10, 64)
				t += v
				if i == 3 || i == 4 {
					idle += v
				}
			}
			total, busy = append(total, t), append(busy, t-idle)
		}
	}
	return busy, total, len(total) > 0
}

func readMem() (used, tot, pct float64) {
	raw, _ := os.ReadFile("/proc/meminfo")
	var t, a float64
	for _, l := range strings.Split(string(raw), "\n") {
		f := strings.Fields(l)
		if len(f) > 1 {
			v, _ := strconv.ParseFloat(f[1], 64)
			switch f[0] {
			case "MemTotal:":
				t = v
			case "MemAvailable:":
				a = v
			}
		}
	}
	if t == 0 {
		return
	}
	return (t - a) / 1048576, t / 1048576, (t - a) / t * 100
}

func osTemps() []Temp {
	out := []Temp{}
	for i := 0; i < 10; i++ {
		raw, err := os.ReadFile(fmt.Sprintf("/sys/class/thermal/thermal_zone%d/temp", i))
		if err == nil {
			if v, err := strconv.ParseFloat(strings.TrimSpace(string(raw)), 64); err == nil {
				out = append(out, Temp{fmt.Sprintf("thermal zone %d", i), v / 1000})
			}
		}
	}
	return out
}
