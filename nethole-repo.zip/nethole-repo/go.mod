module nethole

go 1.22
