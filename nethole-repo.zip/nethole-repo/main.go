package main

import (
	"bufio"
	_ "embed"
	"encoding/binary"
	"encoding/json"
	"errors"
	"io"
	"math"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"sync"
	"time"
)

//go:embed index.html
var indexHTML []byte

var (
	dnsPort   = env("NETHOLE_DNS_PORT", "53")
	webPort   = env("NETHOLE_WEB_PORT", "8053")
	bindAddr  = env("NETHOLE_BIND", "0.0.0.0")
	upstreams = []string{"1.1.1.1", "9.9.9.9"}
	listURLs  = []string{"https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"}
	builtin   = []string{"doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
		"scorecardresearch.com", "adnxs.com", "taboola.com", "outbrain.com", "hotjar.com", "ads.yahoo.com"}
	qtypes  = map[uint16]string{1: "A", 2: "NS", 5: "CNAME", 12: "PTR", 15: "MX", 16: "TXT", 28: "AAAA", 33: "SRV", 65: "HTTPS"}
	appDir  string
	started = time.Now()
)

func env(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

// ---------------------------------------------------------------- block list
type BlockList struct {
	mu       sync.RWMutex
	domains  map[string]struct{}
	cblock   map[string]bool
	callow   map[string]bool
	updating bool
}

var bl = &BlockList{domains: map[string]struct{}{}, cblock: map[string]bool{}, callow: map[string]bool{}}

func (b *BlockList) listFile() string   { return filepath.Join(appDir, "blocklist.txt") }
func (b *BlockList) customFile() string { return filepath.Join(appDir, "custom.json") }

func (b *BlockList) loadCustom() {
	var d struct{ Block, Allow []string }
	raw, err := os.ReadFile(b.customFile())
	if err != nil || json.Unmarshal(raw, &d) != nil {
		return
	}
	b.mu.Lock()
	for _, x := range d.Block {
		b.cblock[x] = true
	}
	for _, x := range d.Allow {
		b.callow[x] = true
	}
	b.mu.Unlock()
}

func (b *BlockList) saveCustom() {
	b.mu.RLock()
	raw, _ := json.Marshal(map[string][]string{"Block": keys(b.cblock), "Allow": keys(b.callow)})
	b.mu.RUnlock()
	os.WriteFile(b.customFile(), raw, 0o644)
}

func keys(m map[string]bool) []string {
	out := []string{}
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

func (b *BlockList) load() {
	found := map[string]struct{}{}
	for _, d := range builtin {
		found[d] = struct{}{}
	}
	if f, err := os.Open(b.listFile()); err == nil {
		sc := bufio.NewScanner(f)
		sc.Buffer(make([]byte, 1<<20), 1<<20)
		for sc.Scan() {
			line := sc.Text()
			if i := strings.IndexByte(line, '#'); i >= 0 {
				line = line[:i]
			}
			p := strings.Fields(line)
			if len(p) >= 2 && (p[0] == "0.0.0.0" || p[0] == "127.0.0.1") && strings.Contains(p[1], ".") {
				found[strings.ToLower(p[1])] = struct{}{}
			}
		}
		f.Close()
	}
	b.mu.Lock()
	b.domains = found
	b.mu.Unlock()
}

func (b *BlockList) update() {
	b.mu.Lock()
	if b.updating {
		b.mu.Unlock()
		return
	}
	b.updating = true
	b.mu.Unlock()
	defer func() { b.mu.Lock(); b.updating = false; b.mu.Unlock() }()
	cl := &http.Client{Timeout: 60 * time.Second}
	var all []byte
	for _, u := range listURLs {
		r, err := cl.Get(u)
		if err != nil {
			return
		}
		body, err := io.ReadAll(r.Body)
		r.Body.Close()
		if err != nil || r.StatusCode != 200 {
			return
		}
		all = append(all, body...)
		all = append(all, '\n')
	}
	if os.WriteFile(b.listFile(), all, 0o644) == nil {
		b.load()
	}
}

func (b *BlockList) blocked(name string) bool {
	parts := strings.Split(strings.TrimSuffix(strings.ToLower(name), "."), ".")
	n := len(parts) - 1
	if n < 1 {
		n = 1
	}
	b.mu.RLock()
	defer b.mu.RUnlock()
	for i := 0; i < n; i++ {
		if b.callow[strings.Join(parts[i:], ".")] {
			return false
		}
	}
	for i := 0; i < n; i++ {
		d := strings.Join(parts[i:], ".")
		if b.cblock[d] {
			return true
		}
		if _, ok := b.domains[d]; ok {
			return true
		}
	}
	return false
}

// --------------------------------------------------------------------- stats
type logEntry struct {
	T  string `json:"t"`
	D  string `json:"d"`
	Q  string `json:"q"`
	C  string `json:"c"`
	S  string `json:"s"`
	Ms int    `json:"ms"`
}

var stats = struct {
	sync.Mutex
	total, blocked int
	lat            float64
	log            []logEntry
	hours          map[int64]*[2]int
	top            map[string]int
}{hours: map[int64]*[2]int{}, top: map[string]int{}}

func addStat(name string, qt uint16, client, status string, ms float64) {
	stats.Lock()
	defer stats.Unlock()
	stats.total++
	h := time.Now().Unix() / 3600
	if stats.hours[h] == nil {
		stats.hours[h] = &[2]int{}
	}
	stats.hours[h][0]++
	if status == "blocked" {
		stats.blocked++
		stats.hours[h][1]++
		stats.top[name]++
	} else {
		stats.lat += ms
	}
	t := qtypes[qt]
	if t == "" {
		t = "?"
	}
	e := logEntry{time.Now().Format("15:04:05"), name, t, client, status, int(math.Round(ms))}
	stats.log = append([]logEntry{e}, stats.log...)
	if len(stats.log) > 40 {
		stats.log = stats.log[:40]
	}
}

// ----------------------------------------------------------------------- dns
var (
	paused   bool
	pausedMu sync.RWMutex
	dnsSet   bool
	dnsError string
)

func isPaused() bool { pausedMu.RLock(); defer pausedMu.RUnlock(); return paused }

func parseQ(d []byte) (string, uint16, int, bool) {
	if len(d) < 17 || d[2]&0x80 != 0 {
		return "", 0, 0, false
	}
	i := 12
	var labels []string
	for {
		if i >= len(d) {
			return "", 0, 0, false
		}
		n := int(d[i])
		if n == 0 {
			i++
			break
		}
		if n&0xC0 != 0 || i+1+n > len(d) {
			return "", 0, 0, false
		}
		labels = append(labels, string(d[i+1:i+1+n]))
		i += 1 + n
	}
	if i+4 > len(d) {
		return "", 0, 0, false
	}
	return strings.Join(labels, "."), binary.BigEndian.Uint16(d[i:]), i + 4, true
}

func blockReply(d []byte, qend int, qt uint16) []byte {
	var rd []byte
	an := byte(0)
	if qt == 1 {
		an, rd = 1, make([]byte, 4)
	} else if qt == 28 {
		an, rd = 1, make([]byte, 16)
	}
	out := []byte{d[0], d[1], 0x81, 0x80, 0, 1, 0, an, 0, 0, 0, 0}
	out = append(out, d[12:qend]...)
	if an == 1 {
		out = append(out, 0xC0, 0x0C, byte(qt>>8), byte(qt), 0, 1, 0, 0, 0, 60, byte(len(rd)>>8), byte(len(rd)))
		out = append(out, rd...)
	}
	return out
}

func forward(data []byte) []byte {
	for _, up := range upstreams {
		c, err := net.DialTimeout("udp", up+":53", 2*time.Second)
		if err != nil {
			continue
		}
		c.SetDeadline(time.Now().Add(2 * time.Second))
		c.Write(data)
		buf := make([]byte, 4096)
		n, err := c.Read(buf)
		c.Close()
		if err == nil {
			return buf[:n]
		}
	}
	return nil
}

func handle(pc net.PacketConn, data []byte, addr net.Addr) {
	t0 := time.Now()
	name, qt, qend, ok := parseQ(data)
	if !ok {
		return
	}
	var resp []byte
	status := "allowed"
	if !isPaused() && bl.blocked(name) {
		resp, status = blockReply(data, qend, qt), "blocked"
	} else if resp = forward(data); resp == nil {
		status = "failed"
	}
	if resp != nil {
		pc.WriteTo(resp, addr)
	}
	host, _, _ := net.SplitHostPort(addr.String())
	addStat(name, qt, host, status, float64(time.Since(t0).Microseconds())/1000)
}

func serveDNS(pc net.PacketConn) {
	for {
		buf := make([]byte, 4096)
		n, addr, err := pc.ReadFrom(buf)
		if err != nil {
			continue
		}
		go handle(pc, buf[:n], addr)
	}
}

// ------------------------------------------------------------ system monitor
type Temp struct {
	Name  string  `json:"name"`
	Value float64 `json:"value"`
}

var sys = struct {
	sync.RWMutex
	Cpu   float64
	Cores []float64
	Ram   map[string]float64
	Load  [3]float64
	Temps []Temp
}{Ram: map[string]float64{}}

func monitor() {
	pb, pt, _ := readCores()
	ncpu := float64(runtime.NumCPU())
	decay := [3]float64{math.Exp(-1.0 / 60), math.Exp(-1.0 / 300), math.Exp(-1.0 / 900)}
	var lastT time.Time
	for {
		time.Sleep(time.Second)
		b, t, ok := readCores()
		var cores []float64
		cpu := 0.0
		if ok && len(b) == len(pb) {
			for i := range b {
				p := 0.0
				if dt := float64(t[i] - pt[i]); dt > 0 {
					p = float64(b[i]-pb[i]) / dt * 100
				}
				p = math.Max(0, math.Min(100, p))
				cores = append(cores, math.Round(p*10)/10)
				cpu += p
			}
			if len(cores) > 0 {
				cpu /= float64(len(cores))
			}
		}
		pb, pt = b, t
		used, total, pct := readMem()
		var temps []Temp
		if time.Since(lastT) > 5*time.Second {
			temps, lastT = osTemps(), time.Now()
		}
		sys.Lock()
		sys.Cpu, sys.Cores = math.Round(cpu*10)/10, cores
		sys.Ram = map[string]float64{"pct": math.Round(pct*10) / 10, "used": math.Round(used*10) / 10, "total": math.Round(total*10) / 10}
		for i := range sys.Load {
			sys.Load[i] = sys.Load[i]*decay[i] + cpu/100*ncpu*(1-decay[i])
		}
		if temps != nil {
			sys.Temps = temps
		}
		sys.Unlock()
	}
}

// ------------------------------------------------------------------ web / api
func guard(w http.ResponseWriter, r *http.Request) bool {
	h := r.Host
	if h != "127.0.0.1:"+webPort && h != "localhost:"+webPort {
		http.Error(w, "forbidden", 403)
		return false
	}
	if r.Method == "POST" && r.Header.Get("X-NetHole") != "1" {
		http.Error(w, "forbidden", 403)
		return false
	}
	return true
}

func statsJSON() []byte {
	stats.Lock()
	allowed := stats.total - stats.blocked
	avg := 0
	if allowed > 0 {
		avg = int(math.Round(stats.lat / float64(allowed)))
	}
	now := time.Now().Unix() / 3600
	hours := make([][2]int, 24)
	for i := range hours {
		if h := stats.hours[now-23+int64(i)]; h != nil {
			hours[i] = *h
		}
	}
	type kv struct {
		K string
		V int
	}
	var tops []kv
	for k, v := range stats.top {
		tops = append(tops, kv{k, v})
	}
	sort.Slice(tops, func(i, j int) bool { return tops[i].V > tops[j].V })
	top := [][]any{}
	for i := 0; i < len(tops) && i < 8; i++ {
		top = append(top, []any{tops[i].K, tops[i].V})
	}
	lg := append([]logEntry{}, stats.log...)
	total, blocked := stats.total, stats.blocked
	stats.Unlock()

	bl.mu.RLock()
	nd, updating := len(bl.domains)+len(bl.cblock), bl.updating
	custom := map[string][]string{"block": keys(bl.cblock), "allow": keys(bl.callow)}
	bl.mu.RUnlock()

	sys.RLock()
	cores := sys.Cores
	if cores == nil {
		cores = []float64{}
	}
	temps := sys.Temps
	if temps == nil {
		temps = []Temp{}
	}
	s := map[string]any{"cpu": sys.Cpu, "cores": cores, "ram": sys.Ram, "freq": 0, "temps": temps,
		"load": []float64{round1(sys.Load[0]), round1(sys.Load[1]), round1(sys.Load[2])}}
	sys.RUnlock()

	out, _ := json.Marshal(map[string]any{"total": total, "blocked": blocked, "avg_ms": avg, "hours": hours,
		"top": top, "log": lg, "uptime": int(time.Since(started).Seconds()), "paused": isPaused(),
		"dns_set": dnsSet, "dns_error": dnsError, "domains": nd, "updating": updating, "sys": s, "custom": custom})
	return out
}

func round1(x float64) float64 { return math.Round(x*10) / 10 }

func api(w http.ResponseWriter, r *http.Request) {
	if !guard(w, r) {
		return
	}
	if r.URL.Path == "/" {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(indexHTML)
		return
	}
	if r.URL.Path == "/api/stats" {
		w.Header().Set("Content-Type", "application/json")
		w.Write(statsJSON())
		return
	}
	if r.Method != "POST" {
		http.NotFound(w, r)
		return
	}
	var body struct {
		Paused, Enable bool
		Domain         string
	}
	json.NewDecoder(io.LimitReader(r.Body, 1<<16)).Decode(&body)
	// the dashboard sends lowercase keys; Go's decoder matches case-insensitively
	dom := strings.ToLower(strings.TrimSpace(body.Domain))
	msg := "OK"
	switch r.URL.Path {
	case "/api/pause":
		pausedMu.Lock()
		paused = body.Paused
		pausedMu.Unlock()
	case "/api/update":
		go bl.update()
		msg = "Updating block lists..."
	case "/api/dns":
		var ok bool
		ok, msg = osSetDNS(body.Enable)
		if ok {
			dnsSet = body.Enable
		}
	case "/api/block", "/api/allow", "/api/remove":
		if strings.Contains(dom, ".") {
			bl.mu.Lock()
			delete(bl.cblock, dom)
			delete(bl.callow, dom)
			if r.URL.Path == "/api/block" {
				bl.cblock[dom] = true
			} else if r.URL.Path == "/api/allow" {
				bl.callow[dom] = true
			}
			bl.mu.Unlock()
			bl.saveCustom()
		}
	case "/api/quit":
		if dnsSet {
			osSetDNS(false)
		}
		go func() { time.Sleep(300 * time.Millisecond); os.Exit(0) }()
		msg = "Bye"
	default:
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"message": msg})
}

func main() {
	if dnsPort == "53" && !isAdmin() {
		if elevate() {
			return
		}
	}
	base, err := os.UserConfigDir()
	if err != nil {
		base = os.TempDir()
	}
	appDir = filepath.Join(base, "NetHole")
	os.MkdirAll(appDir, 0o755)

	url := "http://127.0.0.1:" + webPort
	ln, err := net.Listen("tcp", "127.0.0.1:"+webPort)
	if err != nil { // already running: just show the window
		openUI(url)
		return
	}
	bl.loadCustom()
	bl.load()
	if _, err := os.Stat(bl.listFile()); errors.Is(err, os.ErrNotExist) {
		go bl.update()
	}
	if pc, err := net.ListenPacket("udp", net.JoinHostPort(bindAddr, dnsPort)); err == nil {
		go serveDNS(pc)
	} else {
		dnsError = "DNS server could not start on port " + dnsPort + ": another program is using it."
	}
	go monitor()
	if os.Getenv("NETHOLE_NOGUI") == "" {
		go openUI(url)
	}
	http.Serve(ln, http.HandlerFunc(api))
}
