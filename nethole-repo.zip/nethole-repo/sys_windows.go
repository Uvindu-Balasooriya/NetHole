//go:build windows

package main

import (
	"encoding/binary"
	"os"
	"os/exec"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"unsafe"
)

var (
	kernel32   = syscall.NewLazyDLL("kernel32.dll")
	ntdll      = syscall.NewLazyDLL("ntdll.dll")
	shell32    = syscall.NewLazyDLL("shell32.dll")
	pGlobalMem = kernel32.NewProc("GlobalMemoryStatusEx")
	pNtQSI     = ntdll.NewProc("NtQuerySystemInformation")
	pIsAdmin   = shell32.NewProc("IsUserAnAdmin")
	pShellExec = shell32.NewProc("ShellExecuteW")
)

func hide(c *exec.Cmd) {
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
}

func isAdmin() bool { r, _, _ := pIsAdmin.Call(); return r != 0 }

func elevate() bool {
	exe, err := os.Executable()
	if err != nil {
		return false
	}
	verb, _ := syscall.UTF16PtrFromString("runas")
	file, _ := syscall.UTF16PtrFromString(exe)
	r, _, _ := pShellExec.Call(0, uintptr(unsafe.Pointer(verb)), uintptr(unsafe.Pointer(file)), 0, 0, 1)
	return r > 32
}

func readCores() (busy, total []uint64, ok bool) {
	n := runtime.NumCPU()
	buf := make([]byte, n*48)
	var ret uint32
	r, _, _ := pNtQSI.Call(8, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)), uintptr(unsafe.Pointer(&ret)))
	if r != 0 {
		return nil, nil, false
	}
	cnt := int(ret) / 48
	if cnt > n {
		cnt = n
	}
	for i := 0; i < cnt; i++ {
		b := buf[i*48:]
		idle := binary.LittleEndian.Uint64(b[0:])
		kern := binary.LittleEndian.Uint64(b[8:])
		user := binary.LittleEndian.Uint64(b[16:])
		total = append(total, kern+user)
		busy = append(busy, kern+user-idle)
	}
	return busy, total, true
}

func readMem() (used, tot, pct float64) {
	var m struct {
		Len, Load                        uint32
		Total, Avail, PF, PFA, V, VA, EV uint64
	}
	m.Len = uint32(unsafe.Sizeof(m))
	r, _, _ := pGlobalMem.Call(uintptr(unsafe.Pointer(&m)))
	if r == 0 {
		return
	}
	return float64(m.Total-m.Avail) / (1 << 30), float64(m.Total) / (1 << 30), float64(m.Load)
}

const sensorPS = `
$ErrorActionPreference='SilentlyContinue'
foreach($ns in 'root/LibreHardwareMonitor','root/OpenHardwareMonitor'){
 $s=Get-CimInstance -Namespace $ns -ClassName Sensor | Where-Object {$_.SensorType -eq 'Temperature'}
 if($s){ $s | ForEach-Object { "$($_.Name)|$($_.Value)" }; exit }
}
Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature | ForEach-Object {
 "ACPI thermal zone|" + [math]::Round($_.CurrentTemperature/10-273.15,1) }
`

func osTemps() []Temp {
	c := exec.Command("powershell", "-NoProfile", "-Command", sensorPS)
	hide(c)
	out, err := c.Output()
	temps := []Temp{}
	if err != nil {
		return temps
	}
	for _, line := range strings.Split(string(out), "\n") {
		if i := strings.LastIndex(line, "|"); i > 0 {
			if v, err := strconv.ParseFloat(strings.TrimSpace(line[i+1:]), 64); err == nil && v > 0 && v < 150 {
				temps = append(temps, Temp{strings.TrimSpace(line[:i]), v})
			}
		}
	}
	return temps
}

func osSetDNS(enable bool) (bool, string) {
	cmd := "Get-NetAdapter | Where-Object Status -eq 'Up' | Set-DnsClientServerAddress "
	if enable {
		cmd += "-ServerAddresses 127.0.0.1"
	} else {
		cmd += "-ResetServerAddresses"
	}
	c := exec.Command("powershell", "-NoProfile", "-Command", cmd+"; ipconfig /flushdns")
	hide(c)
	if out, err := c.CombinedOutput(); err != nil {
		return false, "Could not change DNS: " + strings.TrimSpace(string(out))
	}
	if enable {
		return true, "This PC now uses NetHole for DNS."
	}
	return true, "Original DNS settings restored."
}

func openUI(url string) {
	c := exec.Command("cmd", "/c", "start", "", "msedge", "--app="+url)
	hide(c)
	if c.Run() != nil {
		c2 := exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
		hide(c2)
		c2.Start()
	}
}
